import redis, requests, shutil, html
from telethon.sync import TelegramClient,functions,events,errors
from telethon.tl.custom import Button
from telethon.tl.functions.account import UpdateProfileRequest 
from telethon.tl.functions.photos import UploadProfilePhotoRequest
import time
from time import sleep
import random,os,json,time
import logging   , asyncio , random

#------------------------------
#------------ DEBUG 
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',level=logging.INFO)
logger = logging.getLogger(__name__)
#--------------
bot = TelegramClient('@Metiwz_Team',1580776,'8a14d8b6c9c256030f6a3a5f08b3fa51')
bot.start()
info = bot.get_me()
#-------------- Alert 
print(f'Bot Connected on {info.username}  Successfully !')
#-------------- Anti Delete 

apis = [
[4242781,'c8cfe3dc43e95ca4d45efad161466043']]

#--------------
stepBase = redis.Redis(host='localhost', port=6379, db=1 , decode_responses=True)
usersDB = redis.Redis(host='localhost', port=6379, db=2 , decode_responses=True)
#---------  Containers    ----------
admins = [  1900060993 ] #--- admins 


stepBase.set(f"accs"  , 0)
stepBase.set(f"faccs" , 0)
stepBase.set(f"naccs" , 0)
stepBase.set(f"on" , 1)
stepBase.set(f"passCode" , "meti") #--- default pass

def random_line(afile):
    return (random.choice(list(open(afile))))



for item in ['Accounts','Api','Database' , "Limit_temporary" ,"Limit_Parmanent" , "Delete" , "neshast"]:
    if not os.path.exists(item):
        os.mkdir(item)


def get_api(phone): 
    try:
        with open(f'Api/{phone}.txt','r') as myfile:
            content = myfile.read()
            
            return [content.split(':')[0],content.split(':')[1]]
    except FileNotFoundError:
        return 0

def get_file(myfile):
    try:
        with open(f'Database/{myfile}.txt','r') as myfile:
            content = myfile.readlines()
            return content

    except FileNotFoundError:
        return 0

## --- create api_id and api_hash for each Registered Account
def create_api(phone):

    body = f'phone={phone}'
    try:
        response = requests.post('https://my.telegram.org/auth/send_password',data=body,headers= {"Origin":"https://my.telegram.org","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","Accept": "application/json, text/javascript, */*; q=0.01","Reffer": "https://my.telegram.org/auth","X-Requested-With": "XMLHttpRequest","Connection":"keep-alive","Dnt":"1",})
        s = json.loads(response.content)
        return s['random_hash']
    except Exception as e:
        print (str(e))
        return False

#-------------------

def auth(phone,hash_code,pwd):
    data = f"phone={phone}&random_hash={hash_code}&password={pwd}"
    # pxy , port , username , password = random_line("proxylist.txt").split(":")



    # proxies=dict(http=f'socks5h://{username}:{password}@{pxy}:{port}',
    #              https=f'socks5h://{username}:{password}@{pxy}:{port}')

    responses = requests.post('https://my.telegram.org/auth/login',data=data,headers= {"Origin":"https://my.telegram.org","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","Accept": "application/json, text/javascript, */*; q=0.01","Reffer": "https://my.telegram.org/auth","X-Requested-With": "XMLHttpRequest","Connection":"keep-alive","Dnt":"1",})
    
    try:
    
        return responses.cookies['stel_token']
    
    except:
    
        return False

### --- after auth we must logging with sent activation code 
def auth2(stel_token):

    name = '@Metiwz_Team'


    resp = requests.get('https://my.telegram.org/apps',headers={"Dnt":"1","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","Upgrade-Insecure-Requests":"1","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Reffer": "https://my.telegram.org/org","Cookie":"stel_token={0}".format(stel_token),"Cache-Control": "max-age=0",})
    tree = html.fromstring(resp.content)
    api = tree.xpath('//span[@class="form-control input-xlarge uneditable-input"]//text()')
    try:
        return '{0}:{1}'.format(api[0],api[1])
    except:
        s = resp.text.split('"/>')[0]
        value = s.split('<input type="hidden" name="hash" value="')[1]
        on = "hash={0}&app_title=Coded By Metiwz&app_shortname={1}&app_url=&app_platform=desktop&app_desc=".format(value , name)
        requests.post('https://my.telegram.org/apps/create',data=on,headers={"Cookie":"stel_token={0}".format(stel_token),"Origin": "https://my.telegram.org","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Content-Type": "application/x-www-form-urlencoded; charset=UTF-8","Accept": "*/*","Referer": "https://my.telegram.org/apps","X-Requested-With": "XMLHttpRequest","Connection":"keep-alive","Dnt":"1",})
        respv = requests.get('https://my.telegram.org/apps',headers={"Dnt":"1","Accept-Encoding": "gzip, deflate, br","Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4","Upgrade-Insecure-Requests":"1","User-Agent":"Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36","Reffer": "https://my.telegram.org/org","Cookie":"stel_token={0}".format(stel_token),"Cache-Control": "max-age=0",})
        trees = html.fromstring(respv.content)
        apis = trees.xpath('//span[@class="form-control input-xlarge uneditable-input"]//text()')
        return '{0}:{1}'.format(apis[0],apis[1])









#----------------------

@bot.on(events.NewMessage(func= lambda e : e.is_private ))
async def my_event_handler(event):

    userids = event.sender_id


    
    #--------------------------
    if userids in admins and  event.raw_text.startswith("help") or event.raw_text.startswith("/help") :
        await event.reply('''
➖➖➖➖➖➖ 
● **ping **

اطلاع از وضعیت ربات 
➖➖➖➖➖➖ 
● **/send id text**

ارسال پیام به کاربر مورد نظر 

  ➖➖➖➖➖➖ 
● **/fwd**

فور وارد همگانی پیام 
⁉️ بعد از ارسال پیام، پیام بلافاصله به تمامی ممبر ها فور وارد می شود.

  ➖➖➖➖➖➖ 
●** help **

نمایش راهنمای ربات 

  ➖➖➖➖➖➖ 
●**reset**

بازنشانی ( ریست ) کردن امار همگانی 

  ➖➖➖➖➖➖ 
●**reset** ID

بازنشانی آمار برای کاربر خاص 
  ➖➖➖➖➖➖ 
● **/amar**

نمایش آمار همگانی 
⁉️ شامل تعداد اکانت های اهدا شده 
⁉️تعداد اکانت های نشست دار 
⁉️تعداد اکانت های دیلیت شده
  ➖➖➖➖➖➖ 
● ** /amar id **

نمایش آمار اکانت های یک کاربر خاص 
⁉️ شامل تعداد اکانت های اهدا شده 
⁉️تعداد اکانت های نشست دار 
⁉️تعداد اکانت های دیلیت شده

  ➖➖➖➖➖➖ 
● **/start**

استارت ربات

  ➖➖➖➖➖➖ 
● **/off**

خاموش کردن ربات 

  ➖➖➖➖➖➖ 
● **/on**

روشن کردن ربات 

  ➖➖➖➖➖➖ 
● **/pass passWord**

تنظیم پسورد  روی اکانت ها 

⁉️ اکیداا توصیه می شود برا جلوگیری از فراموشی و یا قاطی شدن رمز ربات ها فقط و فقط از یک پسورد استفاده کنید . در صورتی که پسورد رو عو عوض میکنید توجه داشته باشید که پسورد ربات ها اطی نشود !

  ➖➖➖➖➖➖ 
● **/sessions**
            ''')

    if userids in admins and event.raw_text.startswith("/pass"):
        try:

            passCode = event.raw_text.split("/pass")[1]

            passCode = passCode.strip()

            print (passCode)

            stepBase.set("passCode" , passCode)

            await event.reply("👍🏻پسورد 2FA برای ربات ها تنظیم شد")

        except :
            await event.reply("❌ فرمت دستور وارد شده صحیح نیست ")



    if userids in admins and event.raw_text.startswith("/sessions"):
        try:
            shutil.make_archive("Accounts", 'zip', "Accounts")

            await bot.send_file(int(userids) , 'Accounts.zip')
            await asyncio.sleep(0.2)

            await bot.send_message(int(userids) , "All Sessions Sent **Successfully** !")
        except Exception as e:
            await event.reply(str(e))           




    if userids in admins and event.raw_text.startswith("/on"):
        stepBase.set("on" , 1)
        #-------
        await event.reply("✅ ربات در حال حاظر روشن است ")

    elif userids in admins and event.raw_text.startswith("/off"):
        stepBase.set("on" , 0)
        await event.reply('''🔌 ربات خاموش شد 
➖➖➖➖➖➖ 
برای روشن کردن ان از دستور »

/on 
→ @jahanbots
→@jahanbots
استفاده کنید''')



    if userids in admins and  event.raw_text.startswith("/reset") :


        
        if ((event.raw_text.split("/reset"))[1].strip()).isdigit():
            usr = (event.raw_text.split("/reset")[1]).strip()
            print (usr)
            stepBase.set(f"sacc:{usr}" , 0 )

            stepBase.set(f"nacc:{usr}" , 0 )

            stepBase.set(f"facc:{usr}" , 0 )

            await event.reply(f"✅ آمار اهدای اکانت کاربر {usr} با موفقیت ریست شد ")

        else :

            stepBase.set(f"accs", 0)
            stepBase.set(f"faccs",0)
            stepBase.set(f"naccs",0)

            await event.reply('''✅ امار ربات با موفقیت ریست شد 

    ➖➖➖➖➖➖ 

    این امار شامل امار کلی ربات میشود''')


    if userids in admins and event.raw_text.startswith("/fwd"):

        await event.reply('''✅ پیام / بنر خود را ارسال کنید 
➖➖➖➖➖➖ 
⚠️ این بنر به تمامی کاربران فور وارد میشود''')

        stepBase.set(f"step:{userids}"  , "fwd")


    elif userids in admins and  stepBase.get(f"step:{userids}") == "fwd":

        await event.reply('''✅ بنر با موفقیت تنظیم شد 
➖➖➖➖➖➖
در حال ارسال به کاربران لطفا منتظر بمانید !''')


        scount =0
        fcount =0
        for user in usersDB.smembers("user"):

            try:
                await bot.forward_messages(int(user) , event.message)
                await asyncio.sleep(0.2)
                scount+=1

            except  Exception as e:
                print (str(e))
                fcount+=1


        await event.reply(f'''✅ عملیات فور وارد همگانی با موفقیت به اتمام رسید 
➖➖➖➖➖➖
👽 موفقیت آمیر : {scount}

🥵 غیر موفقیت آمیز : {fcount}
➖➖➖➖➖➖''')
        stepBase.set(f"step:{userids}"  , "None")


    elif userids in admins and event.raw_text.startswith("/send"):
        try:
            datas = event.raw_text.split("/send")[1]
            #--------------
            datas = datas.strip()
            
            datas = datas.split(None , 1)
            print (datas)
            id = int(datas[0].strip())
            txt = datas[1]

            #---------------

            try:
                await bot.send_message(id , txt)
                #----------
                await event.reply("✅ پیام شما با موفقیت ارسال شد ")

            except Exception as e :
                await event.reply("Error : " + str(e))

        except  Exception as e:
            print (str(e))
            await event.reply('''⚠️ فرمت صحیح دستور را وارد کنید :

➖➖➖➖➖➖ 

/send id text

➖➖➖➖➖➖
مثال : 
/send 28219976 سلام و خسته نباشید''')

            

    elif userids in admins and  event.raw_text.startswith("/amar") :
        
        if ((event.raw_text.split("/amar"))[1].strip()).isdigit():
            usr = (event.raw_text.split("/amar")[1]).strip()
            print (usr)
            sacc = stepBase.get(f"sacc:{usr}")
            facc = stepBase.get(f"facc:{usr}")
            nacc = stepBase.get(f"nacc:{usr}")


            txt = f'''✅ تعداد اکانت اهدا شده : {sacc}

➖➖➖➖➖➖ 

⚠️ تعداد اکات هایی که نشست پر داشتند : {nacc}

➖➖➖➖➖➖ 

❌ تعداد اکانت های دیلیت شده : {facc}'''
            
            await event.reply(txt)

        else :

            acc  = stepBase.get(f"accs")
            facc = stepBase.get(f"faccs")
            nacc = stepBase.get(f"naccs")

            txt = f'''✅ تعداد کل اکانت ها اهدا شده : {acc}

➖➖➖➖➖➖ 

⚠️ تعداد کل اکانت های مورد دار ( نشست دار ) : {nacc}


➖➖➖➖➖➖ 
❌ تعداد کل دیلیت اکانت شده ها : {facc}'''

            await event.reply(txt)

    #-------------------------


    if stepBase.get("on") == "1":

        if event.raw_text.lower() == "/start":
            stepBase.set(f"step:{userids}" , 'None')
            usersDB.sadd("user" , userids)

            if stepBase.get(f"sacc:{userids}") == None:
                stepBase.set(f"sacc:{userids}" , 0 )


            if stepBase.get(f"facc:{userids}") == None:
                stepBase.set(f"facc:{userids}" , 0 )



            if stepBase.get(f"nacc:{userids}") == None:
                stepBase.set(f"nacc:{userids}" , 0 )



            await event.reply('''🏆 به ربات اهدای اکانت خوشومدی 

    ➖➖➖➖➖➖

    با این ربات میتونی شماره های خودت رو به سادگی اهدا کنی ❕''' , buttons=[[Button.text("💎ارسال شماره" , resize=True)], [Button.text("❕پشتیبانی"  , resize=True) , Button.text("❔اطلاعات من" , resize=True)]] )

        elif event.raw_text == "❕پشتیبانی":
            await event.reply('''⚠️ متن خود را با دقت بنویسید . 
    ➖➖➖➖➖➖ 
    سعی کنید مشکل خود را به صورت کوتاه و مختصر بنویسید ''' , buttons=[[Button.inline("cancel" , "cancel")]])

            stepBase.set(f"step:{userids}" , "contact")



        elif event.raw_text == "❔اطلاعات من":

            usr = event.sender_id
            #----------------
            sacc = stepBase.get(f"sacc:{usr}")
            facc = stepBase.get(f"facc:{usr}")
            nacc = stepBase.get(f"nacc:{usr}")
            #---------------

            txt = f'''
    ❕ تعداد کل اکانت های اهدا شده : {sacc}
    ➖➖➖➖➖➖ 

    ⚠️ تعداد کل اکانت های مورد دار ( نشست دار ) : {nacc}


    ➖➖➖➖➖➖ 
    ❌ تعداد کل دیلیت اکانت شده ها : {facc}

            '''

            await event.reply(txt)



        elif event.raw_text == "💎ارسال شماره":
            await event.reply("✅شماره خود را با پیش شماره ( + ) ارسال کنید :")

            stepBase.set(f"step:{userids}" , "getPhone")
            

        elif event.raw_text == "ping" or event.raw_text == "Ping":
            await event.reply("✅ Online")

        elif event.raw_text and stepBase.get(f"step:{userids}") == "contact":

            txt = event.raw_text

            txt += f"\n ➖➖➖➖➖➖ \n ❓ID : {userids} "

            try:

                await bot.send_message(282199711 , txt)
                await event.reply("✅✅ پیام شما با موفقیت ارسال شد منتظر پیام ادمین باشید ")

            except :

                await event.reply("we have Some Problem ! Try Again Later !")

            stepBase.set(f"step:{userids}" , "None")



        elif event.raw_text.startswith("+") and stepBase.get(f"step:{userids}") == "getPhone":

            phones = event.raw_text
            
            if not phones.split("+")[1].isdigit():
                await event.reply("phone number is invalid !")
                
                return 




            m = await event.reply("please wait ..")
            if os.path.exists('Accounts/{0}.session'.format(phones)):
                await event.reply('**♻️ Account Already In Database !**')
            else :

                try:

                        w = random.choice(apis)

                        new =  TelegramClient('Accounts/{0}'.format(phones),w[0], w[1])
                        #new= TelegramClient('Accounts/{0}'.format(phones),w[0], w[1],proxy=(socks.SOCKS5, "127.0.0.1", 9050))
                        await new.connect()
                        if not await new.is_user_authorized():
                            try:
                                result = await new.send_code_request(phones)
                                stepBase.set(f'code_mode:{userids}' ,  '{0}:{1}:{2}:{3}'.format(phones,result.phone_code_hash,w[0] , w[1]))
                                await new.disconnect()
                                await m.edit('** ✅ Done Api `[{0}]` Created **Successfully** !\nPlease Wait For Send Code...** \n 🏆 code Sent to account'.format(phones))

                                stepBase.set(f"step:{userids}" , "getCode")

                            except Exception as e:
                                print (str(e))
                                await event.reply('**❌ Error In Send Code Please Try Again Later...**')
                                try:
                                    await new.disconnect()
                                    os.remove('Accounts/{}.session'.format(phones))
                                except :
                                    pass
                except KeyError:
                    await event.reply('**🔰 No Any Account In Queue \n use /start **')    
                    stepBase.set(f"step:{userids}" , 'None')

        elif event.raw_text.isdigit() and stepBase.get(f"step:{userids}") == "getCode":
            try:
                w = random.choice(apis)
                key = stepBase.get(f'code_mode:{userids}')
                await event.reply('**🔰 Please Wait ... **')
                new =  TelegramClient('Accounts/{0}'.format(key.split(':')[0]), w[0] , w[1])

                #new =  TelegramClient('Accounts/{0}'.format(key.split(':')[0]), w[0] , w[1] ,proxy=(socks.SOCKS5, "127.0.0.1", 9050))
                await new.connect()

                await new(functions.auth.SignInRequest(phone_number=key.split(':')[0],phone_code_hash=key.split(':')[1],phone_code=event.raw_text))
                info = await new.get_me()
                #print (info)

                await event.reply('''** \n ▬▭▬▭▬▭▬ \n 🔆 Done Api [{0}] \n ▬▭▬▭▬▭▬ \n please  wait `60s` we check if your Account hasn't any Active Session ❕ \n \n ▬▭▬▭▬▭▬ \n Account Info\n 🔆 Account Username : {1}\n \n ▬▭▬▭▬▭▬ \n 🔆 Account Phone : +{2}\n  \n ▬▭▬▭▬▭▬ \n 🔆 Account FirstName : {3}\n \n ▬▭▬▭▬▭▬ \n 🔆 Account LastName : {4}** \n ▬▭▬▭▬▭▬ \n'''.format(key.split(':')[2]+':'+key.split(':')[3],str(info.username),str(info.phone),info.first_name,info.last_name) , buttons=[[Button.inline("✅ check " ,f"False|{time.time()}|+{info.phone}")]])
                
                stepBase.set(f"step:{userids}" , 'None')

                await new.disconnect()

            except errors.rpcerrorlist.PhoneCodeExpiredError:
                await event.reply('**⚠️ phone code Exipired \n ▬▭▬▭▬▭▬ \n  Please  Enter Phone number Again \n  **')
                await new.disconnect()
                os.remove('Accounts/{}.session'.format(key.split(':')[0]))
                stepBase.set(f"step:{userids}" , 'None')

            except errors.SessionPasswordNeededError:
                await event.reply('**⚠️ Session Need Password Please Enter Password ! **')
                await new.disconnect()
                os.remove('Accounts/{}.session'.format(key.split(':')[0]))
                stepBase.set(f"step:{userids}" , "2fa")    

            except KeyError:
                await new.disconnect()
                await event.reply('**⚠️ No Any Account In Queue**')
            
            except errors.rpcerrorlist.PhoneCodeInvalidError:
                await new.disconnect()
                await event.reply("⚠️ Invalid Code ! \n Try Again ")
                os.remove('Accounts/{}.session'.format(key.split(':')[0]))


            except Exception as e :
                await new.disconnect()
                os.remove('Accounts/{}.session'.format(key.split(':')[0]))
                print (str(e))
                await event.reply("خطای ناشناخته \n لطفا مجددا با زدن /start فراند را طی کنید ")
                stepBase.set(f"step:{userids}" , 'None')


        elif not event.raw_text.isdigit() and stepBase.get(f"step:{userids}") == "getCode" and event.raw_text != "💎ارسال شماره" and event.raw_text != "❔اطلاعات من" and event.raw_text != "❕پشتیبانی":


            await event.reply("⚠️ Please Enter the Code Currectly ")

        elif  stepBase.get(f"step:{userids}") == "2fa":
            try:

                key = stepBase.get(f'code_mode:{userids}')
                m= await event.reply('**♻️ Please Wait ... **')
                k2 = get_api(key.split(':')[0])

                k2 = random.choice(apis)

                new =  TelegramClient('Accounts/{0}'.format(key.split(':')[0]),int(k2[0]),k2[1]  )
                #new =  TelegramClient('Accounts/{0}'.format(key.split(':')[0]),int(k2[0]),k2[1] ,proxy=(socks.SOCKS5, "127.0.0.1", 9050))
                await new.connect()

                await new.sign_in(password=event.raw_text)
                
                info = await new.get_me()

                await new.disconnect()
                await event.reply('''** \n ▬▭▬▭▬▭▬ \n 🔆 Done Api [{0}] \n ▬▭▬▭▬▭▬ \n please  wait `60s` we check if your Account hasn't any Active Session ❕ \n \n ▬▭▬▭▬▭▬ \n Account Info\n 🔆 Account Username : {1}\n \n ▬▭▬▭▬▭▬ \n 🔆 Account Phone : +{2}\n  \n ▬▭▬▭▬▭▬ \n 🔆 Account FirstName : {3}\n \n ▬▭▬▭▬▭▬ \n 🔆 Account LastName : {4}** \n ▬▭▬▭▬▭▬ \n'''.format(key.split(':')[2]+':'+key.split(':')[3],str(info.username),str(info.phone),info.first_name,info.last_name) , buttons=[[Button.inline("✅ check " , f"True|{time.time()}|+{info.phone}|{event.raw_text}")]])
                
                stepBase.set(f"step:{userids}" , 'None')

            except KeyError:
                await event.reply('** No Any Account In Queue**')
            except errors.PasswordHashInvalidError:
                await event.reply('**❌ Password Is Invalid Please Enter True Password ! **')

                await new.disconnect()
                os.remove('Accounts/{}.session'.format(key.split(':')[0]))

            except Exception as e :
                print (str(e))
                await event.reply("خطای ناشناخته \n لطفا زدن /start دوباره تلاش کنید ")
                await new.disconnect()
                os.remove('Accounts/{}.session'.format(key.split(':')[0]))
                stepBase.set(f"step:{userids}" , 'None')
            #await new.disconnect()










# ----- Time|time|phone
@bot.on(events.CallbackQuery)
async def callback(events):
    userids = events.sender_id
    
    callback = events.data.decode()

    if (stepBase.get("on") == "1"):

        if callback == "cancel":
            stepBase.set(f"step:{userids}" , "None")
            await events.answer("⚠️ ارتباط شما با موفقیت قطع شد ")
            await events.delete()

        elif callback.startswith('True') or callback.startswith("False") :
            
            

            if time.time() - int(callback.split('|')[1].split('.')[0]) > 10:
                await events.answer('کمی صبر کنید ...')
                api  = random.choice(apis)
                aid = api[0]
                ah  = api[1]


                client = TelegramClient("Accounts/"+callback.split('|')[2]+".session", aid , ah )
                #client = TelegramClient("Accounts/"+callback.split('|')[2]+".session", aid , ah ,proxy=(socks.SOCKS5, "127.0.0.1", 9050))
                
                await client.connect()
                dct = callback.split('|')
                #--------------------

                try:
                    await client(functions.auth.ResetAuthorizationsRequest())
                except Exception as e:
                    print ("ResetAuthorizationsRequest ===>" ,str(e))
                    pass
                
                #--------------------

                try:

                    result = await client(functions.account.GetAuthorizationsRequest())
                    
                    if len(result.authorizations) == 1:
                    #if 1== 1:
                        if dct[0] == 'True': #---- password 2fa dare !
                            print ("password 2fa dare !")
                            await events.edit("🏆 اکانت شما با موفقیت اهدا شد ❕")
                            await asyncio.sleep(random.randint(1 , 2))
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "❌"), Button.inline( "❌", "❌")] , [Button.inline( "LastName  ", "❌"), Button.inline( "❌", "❌")] , [Button.inline( "Bio", "❌"), Button.inline( "❌", "❌")] ])
                    

                            #--------
                            stepBase.incr(f"sacc:{userids}" )  #---- success Acc
                            stepBase.incr(f"accs")
                            #----------
                            a_pass = stepBase.get("passCode")
                            
                            passwd = dct[3]

                            print ("new password : " , a_pass , "old pass : " , passwd)

                            fname = random_line("fnames.txt")
                            lname = random_line("lnames.txt")
                            about = random_line("about.txt")
                            files = os.listdir('images')
                           
                            print ("files" , files)
                            mimg = random.choice(files)


                            print ("fname : " , fname , "lname: " , lname , "about : " , about  , "image :"  , mimg )
                            upload_file = await client.upload_file("images/"+mimg)
                            await client(UploadProfilePhotoRequest(upload_file))
                            



                            await client(UpdateProfileRequest(first_name=fname))
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "❌"), Button.inline( "❌", "❌")] , [Button.inline( "Bio", "❌"), Button.inline( "❌", "❌")] ])

                            await asyncio.sleep(1 , 2)

                            await client(UpdateProfileRequest(last_name=str(lname)))
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "✅"), Button.inline( "✅", "❌")] , [Button.inline( "Bio", "❌"), Button.inline( "✅", "❌")] ])
                            await asyncio.sleep(1 , 2)

                            await client(UpdateProfileRequest(about=str(about)))
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "Bio", "✅"), Button.inline( "✅", "✅")] ])
                            await asyncio.sleep(1 , 2)                            


                            await client.edit_2fa(current_password=passwd,new_password=a_pass)
                            
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "Bio", "✅"), Button.inline( "✅", "✅")] ,[Button.inline( "Password", "✅"), Button.inline( "✅", "✅")] ])
                            

                            await client.disconnect()


                        if dct[0] == "False":#--- pass 2FA nadare 
                            await events.reply("🏆 اکانت شما با موفقیت اهدا شد ❕")

                            #--------
                            stepBase.incr(f"sacc:{userids}" )  #---- success Acc
                            stepBase.incr(f"accs")
                            #----------
                            a_pass = stepBase.get("passCode")
                            
                            

                            print ("new password :" , a_pass )


                            fname = random_line("fnames.txt")
                            lname = random_line("lnames.txt")
                            about = random_line("about.txt")
                            files = os.listdir('images')
                           
                            print ("files" , files)
                            mimg = random.choice(files)
                            upload_file = await client.upload_file("images/"+mimg)
                            await client(UploadProfilePhotoRequest(upload_file))
                            

                            print ("fname : " , fname , "lname:" , lname , "about : " , about )



                            await client(UpdateProfileRequest(first_name=fname))
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "❌", "❌")] , [Button.inline( "LastName  ", "❌"), Button.inline( "❌", "❌")] , [Button.inline( "Bio", "❌"), Button.inline( "❌", "❌")] ])

                            await asyncio.sleep(1 , 2)

                            await client(UpdateProfileRequest(last_name=str(lname)))
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "✅"), Button.inline( "✅", "❌")] , [Button.inline( "Bio", "❌"), Button.inline( "❌", "❌")] ])
                            await asyncio.sleep(1 , 2)

                            await client(UpdateProfileRequest(about=str(about)))
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "Bio", "✅"), Button.inline( "✅", "✅")] ])
                            await asyncio.sleep(1 , 2)                            
                    
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "✅"), Button.inline( "✅", "❌")] , [Button.inline( "Bio", "✅"), Button.inline( "✅", "✅")] ,[Button.inline( "Password", "✅"), Button.inline( "❌", "✅")] ])
                            

                            await client.edit_2fa(new_password=a_pass)
                            #----------
                            await events.edit('| Please wait ... \n👽 Agent : {} '.format(callback.split('|')[2]), buttons=[[Button.inline( "Connection .. ", "✅"), Button.inline( "✅ ", "✅")] ,[Button.inline( "FirstName ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "LastName  ", "✅"), Button.inline( "✅", "✅")] , [Button.inline( "Bio", "✅"), Button.inline( "✅", "❌")] ,[Button.inline( "Password", "✅"), Button.inline( "✅", "✅")] ])
                            
                            await client.disconnect()                            


                    else:

                        #---------------
                        stepBase.incr(f"nacc:{userids}") #----- neshast
                        stepBase.incr(f"naccs")
                        #--------------
                        await events.reply('⚠️ نشستهای فعال اکانت خالی نیست.')
                        await client.disconnect()
                        shutil.move(f"Accounts/{dct[2]}.session", f"neshast/{dct[2]}.session")

                except errors.UserDeactivatedBanError:
                    stepBase.incr(f"facc:{userids}") #---- mored dar acc
                    stepBase.incr(f"faccs")
                    await events.edit('⚠️متاسفانه اکانت شما دیلیت شده است لطفا اکانت دیگری را وارد نمایید.')
                    await client.disconnect()

                    shutil.move(f"Accounts/{dct[2]}.session", f"Delete/{dct[2]}.session")
                except errors.UserDeactivatedError:
                    stepBase.incr(f"facc:{userids}") #---- mored dar acc
                    stepBase.incr(f"faccs")
                    await events.edit('⚠️متاسفانه اکانت شما دیلیت شده است لطفا اکانت دیگری را وارد نمایید.')
                    await client.disconnect()
                    shutil.move(f"Accounts/{dct[2]}.session", f"Delete/{dct[2]}.session")
                except errors.SessionExpiredError:
                    stepBase.incr(f"facc:{userids}") #---- mored dar acc
                    stepBase.incr(f"faccs")
                    await events.edit(f'⚠️ شماره {dct[2]} از دسترس ربات خارج شده است و امکان ثبت آن نیست.')
                    await client.disconnect()
                    shutil.move(f"Accounts/{dct[2]}.session", f"Delete/{dct[2]}.session")
                except errors.SessionRevokedError:
                    stepBase.incr(f"facc:{userids}") #---- mored dar acc
                    stepBase.incr(f"faccs")
                    await events.edit(f'⚠️ شماره {dct[2]} از دسترس ربات خارج شده است و امکان ثبت آن نیست.')
                    await client.disconnect()
                    shutil.move(f"Accounts/{dct[2]}.session", f"Delete/{dct[2]}.session")
                except errors.rpcerrorlist.PasswordHashInvalidError:
                    stepBase.incr(f"facc:{userids}") #---- mored dar acc
                    stepBase.incr(f"faccs")
                    await events.edit(f'⚠️ تایید دو مرحله ای شماره {dct[2]} تغییر کرده است و امکان ثبت آن نیست.')     
                
                    shutil.move(f"Accounts/{dct[2]}.session", f"Delete/{dct[2]}.session")
                except Exception as e:
                    stepBase.incr(f"facc:{userids}") #---- mored dar acc
                    stepBase.incr(f"faccs")
                    await client.disconnect()
                    print (str(e))
                    await events.edit('⚠️خطای ناشناخته از تلگرام لطفا دوباره اکانت را وارد نمایید یا اکانت دیگری را وارد ربات نمایید.')
                   
                    shutil.move(f"Accounts/{dct[2]}.session", f"Delete/{dct[2]}.session")

            else:
                await events.answer('هنوز 1 دقیقه نشده است لطفا {} ثانیه دیگر صبر کنید با تشکر'.format(60 - (time.time() - int(callback.split('|')[1].split('.')[0]))  ).split('.')[0])










bot.run_until_disconnected()